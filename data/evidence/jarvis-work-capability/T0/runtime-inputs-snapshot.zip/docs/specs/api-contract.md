# API 契约（API Contract · 能力层对外）

- **版本**：v1.0 · 2026-10-16
- **性质**：技术规格（L0-L10 能力层对外接口；对齐 registry.md 能力表与 protocol-contract HS/SD 消息号）
- **核心**：能力层唯一入口是服务器侧编排；宿主不直连能力（architecture §3）；接口稳定才可版本化

## 1. 能力层暴露面

| 层 | 能力 | 入口（编排调用） |
|---|---|---|
| L0 | 语音/文字四 IO | 宿主经 HS-001/002 进，HS-003/004 出（服务器侧 ASR/TTS） |
| L1 | 意图理解 | `intent.parse(text, sessionId)` → 意图+隐含补全 |
| L2 | 领域定义 | `domain.resolve(intent)` → 领域内容清单 |
| L3 | 执行/外部接入 | `exec.run(plan, ctx)` → 数据源/设备/多模型调用（降级四层） |
| L4 | 编排与组合窗口 | `scene.orchestrate(content, intent)` → 组件树 DSL（HS-005） |
| L5 | 表达与总结 | `report.compose(results)` → 汇报三规则聚合文本 |
| L6 | 输出呈现 | `voice.speak(text, state)` → TTS 流 + 状态（倾听/思考/说话） |
| L7 | 交互循环 | `dialog.ask(question)` / `queue.list|reorder|cancel` → 征询/队列 |
| L8 | 行为约束 | `guard.check(action, scope)` → 权限/越界判定（受控执行） |
| L9 | 记忆 | `memory.read(query)` / `memory.write(fact)`（TD-02 冻结后定实现） |
| L10 | 范式引擎 | `paradigm.run(flowId, input)` → 7 环流程强制检查 |

## 2. 契约规则（强制）

- 调用一律走服务器编排，宿主/外部不得跳过 L10 范式检查直达能力。
- 返回统一：`{ ok, data?, error? }`；错误码对齐 protocol-contract §4（E-4xx/5xx/6xx/7xx）。
- 能力接口签名变更 = 接口契约变更，登记 M3 变更评审。
- 幂等：读类可重试；写/控制类带请求 ID 防重。

## 3. 对齐 HS/SD 消息号

- HS-001~010 承载宿主↔服务器（本表入口经编排调用）。
- SD-001~008 承载服务器↔设备（本表 L3 执行内部路由）。

## 4. 变更登记

| 版本 | 日期 | 变更 |
|---|---|---|
| v1.0 | 2026-10-16 | 初版：L0-L10 能力入口/契约规则/消息号对齐 |
