"""Structured reply tests."""
